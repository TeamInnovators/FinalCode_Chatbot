﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AppsetupChatbot
{
    public class ChatbotModel
    {
      
            public string UserName { get; set; }
            public string Rating { get; set; }
            public string Comments { get; set; }
        
    }
}
