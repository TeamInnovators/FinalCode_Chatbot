﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AppsetupChatbot;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Http;

using System;

using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.Bot.Builder.TraceExtensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;


namespace Microsoft.BotBuilderSamples 
{
    // This bot will respond to the user's input with suggested actions.
    // Suggested actions enable your bot to present buttons that the user
    // can tap to provide input. 
    public class SetupBot : ActivityHandler
    {
        // public const string WelcomeText = "Please Choose the option below:";

        public static string _user = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

        public string _rating;
        private static BotState _userState;
        const string SessionName = "_Name";

        protected readonly int ExpireAfterSeconds;

        //public System.Web..HttpSessionState Session { get; }

        private static string WelcomeMessage = "Hello " + _user + ", Welcome to Application Setup Wizard!";

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            // Send a welcome message to the user and tell them what actions they may perform to use this bot
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    var cardAttachment = CreateAdaptiveCardAttachment();

                    await turnContext.SendActivityAsync(MessageFactory.Attachment(cardAttachment), cancellationToken);

                    await turnContext.SendActivityAsync(WelcomeMessage, cancellationToken: cancellationToken);

                    await SendIntroCardAsync(turnContext, cancellationToken);
                }
            }
        }
        public SetupBot(UserState userState)
        {
           
            _userState = userState;

        }
        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {

            List<ChatbotModel> _data = new List<ChatbotModel>();
            var welcomeUserStateAccessor1 = _userState.CreateProperty<ChatbotModel>(nameof(ChatbotModel));
            var didBotWelcomeUser = await welcomeUserStateAccessor1.GetAsync(turnContext, () => new ChatbotModel(), cancellationToken);
            if (string.IsNullOrEmpty(turnContext.Activity.Text) && turnContext.Activity.Value != null)
            {


                // Conditionally convert based off of input ID of Adaptive Card
                if ((turnContext.Activity.Value as JObject)["userText"] != null)
                {
                    didBotWelcomeUser.Comments = (turnContext.Activity.Value as JObject)["userText"].ToString();
                    didBotWelcomeUser.UserName = _user;
                }
                //turnContext.Activity.Text = ((Newtonsoft.Json.Linq.JValue)((Newtonsoft.Json.Linq.JContainer)(turnContext.Activity.Value as JObject).First).First).Value.ToString();


                //List<ChatbotModel> _data = new List<ChatbotModel>();

                _data.Add(new ChatbotModel()
                {
                    UserName = didBotWelcomeUser.UserName,
                    Rating = didBotWelcomeUser.Rating,
                    Comments = didBotWelcomeUser.Comments
                });

                string json = JsonConvert.SerializeObject(_data.ToArray());
                string startupPath = System.IO.Directory.GetCurrentDirectory() + @"\Chatbot.JSON";
                if (File.Exists(startupPath))
                {
                    System.IO.File.AppendAllText(startupPath, json);
                    await turnContext.SendActivityAsync("Thanks for your feedback!");
                    var activity = MessageFactory.Carousel(
                    new Attachment[]
                    {
                 new HeroCard(
                 buttons: new CardAction[]
                 {
                   new CardAction(title: "Restart", type: ActionTypes.ImBack, value: "restart")
                  }).ToAttachment()

                     });

                    // Send the activity as a reply to the user.
                    await turnContext.SendActivityAsync(activity);
                    turnContext.Activity.Text = "closed";
                }
                else
                {
                    //write string to file
                    System.IO.File.WriteAllText(startupPath, json);
                    await turnContext.SendActivityAsync("Thanks for your feedback!");
                    var activity = MessageFactory.Carousel(
                    new Attachment[]
                    {
                 new HeroCard(
                 buttons: new CardAction[]
                 {
                   new CardAction(title: "Restart", type: ActionTypes.ImBack, value: "restart")
                  }).ToAttachment()

                     });

                    // Send the activity as a reply to the user.
                    await turnContext.SendActivityAsync(activity);
                    turnContext.Activity.Text = "closed";
                }
            }
            
                var text = turnContext.Activity.Text.ToLowerInvariant();

                switch (text)
                {
                    case "hello":
                    case "hi":
                        await turnContext.SendActivityAsync($"You said {text}.", cancellationToken: cancellationToken);
                        break;
                    case "intro":
                    case "help":
                        await StartAsync(turnContext, cancellationToken);
                        break;
                    case "overview":
                    case "faq":
                        await SendIntroCardAsync(turnContext, cancellationToken);
                        break;
                    case "learn how to setup":
                    case "setup":
                        await SendCodeSetupCardAsync(turnContext, cancellationToken);
                        break;
                    case "exit":
                        await StartAsync(turnContext, cancellationToken);
                        break;
                    case "1":
                        _rating = "1";
                        await DisplayCardAsync("1", turnContext, cancellationToken);
                        break;
                    case "2":
                        _rating = "2";
                        await DisplayCardAsync("2", turnContext, cancellationToken);
                        break;
                    case "3":
                        _rating = "3";
                        await DisplayCardAsync("3", turnContext, cancellationToken);
                        break;
                    case "4":
                        _rating = "4";
                        await DisplayCardAsync("4", turnContext, cancellationToken);
                        break;
                    case "5":
                        _rating = "5";
                        await DisplayCardAsync("5", turnContext, cancellationToken);
                        break;
                case "closed":
                    break;

                default:
                        await turnContext.SendActivityAsync(WelcomeMessage, cancellationToken: cancellationToken);
                        await SendIntroCardAsync(turnContext, cancellationToken);
                    break;
                }
            }
        
        private static async Task SendWelcomeMessageAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in turnContext.Activity.MembersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(
                        $" Hello " + _user + ", Welcome to Application Setup Wizard!",
                        cancellationToken: cancellationToken);


                    await SendIntroCardAsync(turnContext, cancellationToken);
                }
            }
        }

        private static async Task StartAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {


            var feedback = new HeroCard()
            {
                Title = "Please provide rating from 1 to 5 where 5 is the Highest & 1 is Lowest",
                Buttons = new List<CardAction>()
                {

                    new CardAction(){ Title = "5.Excellent", Type=ActionTypes.ImBack, Value="5" },
                    new CardAction(){ Title = "4.Good", Type=ActionTypes.ImBack, Value="4" },
                    new CardAction(){ Title = "3.Ok", Type=ActionTypes.ImBack, Value="3" },
                    new CardAction(){ Title = "2.Bad", Type=ActionTypes.ImBack, Value="2" },
                    new CardAction(){ Title = "1.Very bad", Type=ActionTypes.ImBack, Value="1" }



                },

            };

            var response = MessageFactory.Attachment(feedback.ToAttachment());
            await turnContext.SendActivityAsync(response, cancellationToken);

        }
        private async Task DisplayCardAsync(string rating, ITurnContext stepContext, CancellationToken cancellationToken)
        {
            // Display the Adaptive Card;
            var cardPath = GetType().Assembly.GetManifestResourceNames().First(name => name.EndsWith("AdaptiveCard.json"));

            using (var stream = GetType().Assembly.GetManifestResourceStream(cardPath))
            {
                using (var reader = new StreamReader(stream))
                {
                    var adaptiveCard = reader.ReadToEnd();
                    var cardAttachment = new Attachment()
                    {
                        ContentType = "application/vnd.microsoft.card.adaptive",
                        Content = JsonConvert.DeserializeObject(adaptiveCard),
                    };
                    var message = MessageFactory.Text("");
                    string newrating = rating;
                    var selectedRating = _userState.CreateProperty<ChatbotModel>(nameof(ChatbotModel));
                    var selectedRatinginput = await selectedRating.GetAsync(stepContext, () => new ChatbotModel(), cancellationToken);
                    selectedRatinginput.Rating = newrating;
                    _rating = selectedRatinginput.Rating;
                     message.Attachments = new List<Attachment>() { cardAttachment };
                    // message.CallerId = _rating;
                    await _userState.SaveChangesAsync(stepContext, cancellationToken: cancellationToken);
                    await stepContext.SendActivityAsync(message, cancellationToken);

                   

                }
            }

        }

        private static async Task SendIntroCardAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            var card = new HeroCard
            {
                Title = "Please Choose the Options:",
                //Text = @"Please Choose the Options::::",
                Images = new List<CardImage>() { new CardImage("https://aka.ms/bf-welcome-card-image") },
                Buttons = new List<CardAction>()
                {
                    new CardAction(ActionTypes.OpenUrl, "Get an overview", "http://localhost:3978/airplane.png", text:"overview", "Get an overview", "https://docs.microsoft.com/en-us/azure/bot-service/?view=azure-bot-service-4.0"),
                    new CardAction(ActionTypes.ImBack, "Learn how to setup", null, text:"codesetup", "Learn how to setup",value: "Learn how to setup", ""),
                    new CardAction(ActionTypes.OpenUrl, "Ask a question", null, text:"faq", "Ask a question", "http://localhost:3978/FAQBot.docx"),
                    new CardAction(ActionTypes.ImBack, "Exit", null, text:"exit", "Exit", value: "exit", "")

                }

            };



            var response = MessageFactory.Attachment(card.ToAttachment());
            await turnContext.SendActivityAsync(response, cancellationToken);
        }

        private static async Task SendCodeSetupCardAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            StringBuilder _sbcodesetupmessage = new StringBuilder("Please follow the below Setps:" + System.Environment.NewLine + "Step 1:Take the code from bit bucket");
            _sbcodesetupmessage.Append(System.Environment.NewLine + "Step 2:By using TFS CLONE the code from github to local");
            _sbcodesetupmessage.Append(System.Environment.NewLine + "Step 3:Change the Branchversion to release");
            _sbcodesetupmessage.Append(System.Environment.NewLine + "Step 4:Check the Network drive is connected or not");
            _sbcodesetupmessage.Append(System.Environment.NewLine + "Step 5:Build the solution");
            _sbcodesetupmessage.Append(System.Environment.NewLine + "Step 6:Copy the dlls to Publish folder");


            var card = new HeroCard
            {
                Title = "Instructions:",
                Text = _sbcodesetupmessage.ToString(),
                Images = new List<CardImage>() { new CardImage("https://aka.ms/bf-welcome-card-image") },
                Buttons = new List<CardAction>()
                {
                    new CardAction(ActionTypes.OpenUrl, "Get an overview", null, "Get an overview", "Get an overview", "https://docs.microsoft.com/en-us/azure/bot-service/?view=azure-bot-service-4.0"),
                    new CardAction(ActionTypes.ImBack, "Learn how to setup", null, "Ask a question", "Ask a question", "Learn how to setup", "CodeSetUp"),
                    new CardAction(ActionTypes.OpenUrl, "Ask a question", "https://github.com/amido/azure-vector-icons/raw/master/renders/cloud-service.png", "Learn how to deploy", "Learn how to deploy", "http://localhost:3978/FAQBot.docx"),
                    new CardAction(ActionTypes.ImBack, "Exit", null, text:"exit", "Exit", value: "exit", "")
                }

            };

            var response = MessageFactory.Attachment(card.ToAttachment());
            await turnContext.SendActivityAsync(response, cancellationToken);
        }

        // Load attachment from embedded resource.
        private Attachment CreateAdaptiveCardAttachment()
        {
            var cardResourcePath = GetType().Assembly.GetManifestResourceNames().First(name => name.EndsWith("welcomeCard.json"));

            using (var stream = GetType().Assembly.GetManifestResourceStream(cardResourcePath))
            {
                using (var reader = new StreamReader(stream))
                {
                    var adaptiveCard = reader.ReadToEnd();
                    return new Attachment()
                    {
                        ContentType = "application/vnd.microsoft.card.adaptive",
                        Content = JsonConvert.DeserializeObject(adaptiveCard),
                    };
                }
            }
        }
       

    }
}
